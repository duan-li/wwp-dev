24 July 2015 
5 December 2015 Build with Visual Studio 2015 Update 1

                                                Apache Lounge Distribution

                                          mod_xsendfile 1.0-P1 Apache 2.4 Win64 VC14

# Original source by: Nils Maier
# Original Home: https://tn123.org/mod_xsendfile/
# Binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/
#
# Included fix: https://github.com/nmaier/mod_xsendfile/issues/8


# Install:

- Copy mod_xsendfile.so to your modules folder 

# Add to your httpd.conf

LoadModule xsendfile_module modules/mod_xsendfile.so


# Configuration:

  See the Readme.html in the docs folder




Enjoy,

Steffen
