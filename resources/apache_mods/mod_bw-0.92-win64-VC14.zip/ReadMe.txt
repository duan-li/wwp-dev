24 July 2015 
5 December 2015 Build with Visual Studio 2015 Update 1

                                            Apache Lounge Distribution

                                     mod_bw 0.92 for Apache 2.4.x Win64 VC14



# Original Home: http://ivn.cl/category/apache/
# Binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/


# Install:

- Copy mod_bw to your modules folder 


# Add to your httpd.conf


LoadModule bw_module modules/mod_bw.so

# Configuration, see mod_bw.txt

Enjoy,

Steffen
