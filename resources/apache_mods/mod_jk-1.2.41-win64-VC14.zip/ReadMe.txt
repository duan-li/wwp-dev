31 August 2015 
5 December 2015 Build with Visual Studio 2015 Update 1


                                       Apache Lounge Distribution

                                   mod_jk 1.2.41  for Apache 2.4 Win64 VC14


# Original source by: http://tomcat.apache.org
# Binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/

Applied fix jk-status timezone, see https://svn.apache.org/viewvc?view=revision&revision=1698316 


Enjoy,

Steffen
